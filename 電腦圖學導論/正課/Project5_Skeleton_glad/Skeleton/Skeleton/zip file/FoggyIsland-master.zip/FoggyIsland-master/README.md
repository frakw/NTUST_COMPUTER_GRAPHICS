# FoggyIsland
Foggy Island is an landscape scene constructed with OpenGL and C++. This project focuses on the encapsulation and management of basic rendering components like framebuffers, and some basic optimizations, as well as further optimizations with GPU profiling tools to enhance framerate. 
Foggy Island是一个用OpenGL和C++构建的室外场景，着重点是封装与组织framebuffer等渲染基础组件、以及从底层开始实现各种基本的渲染效果、一些基本优化、还有用GPU profile工具针对帧率进行的优化。
